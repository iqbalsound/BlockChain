**What version of Go are you running?** (Paste the output of `go version`)


**What version of gorilla/mux are you at?** (Paste the output of `git rev-parse HEAD` inside `$GOPATH/src/github.com/gorilla/mux`)


**Describe your problem** (and what you have tried so far)


**Paste a minimal, runnable, reproduction of your issue below** (use backticks to format it)

